# Readme

We Have 2 File(s)

## clustering

This file is for make a cluster image by using the color from the received image, cluster, and total_run

### How to compile

> make clustering

### How to use

>./clustering [filename]>[file_output] [cluster] [total_run]

you need to pass some arguments in here.
**filename** is the picture that you want to modified
**file_output** is the name of output picture
**cluster** is total cluster that want need to be created
**total_run** is total clustering run

## clustering_update

This file is for make a cluster image by using color and coordinate from the received input image, cluster, and total_run

### How to compile

> make clustering_update

### How to use

>./clustering_update [filename]>[file_output] [cluster] [total_run]

you need to pass some arguments in here.
**filename** is the picture that you want to modified
**file_output** is the name of output picture
**cluster** is total cluster that want need to be created
**total_run** is total clustering run
